{{ config(materialized='table') }}

WITH base_data AS (
    SELECT * FROM {{ ref('int_courses_standardized') }}
),

fact_data AS (
    SELECT
        -- Join with dim_offering to get the surrogate key
        COALESCE(do.offering_sk, -1) AS offering_sk,
        
        -- ربط بجميع الـ Dimensions مع ضمان عدم وجود NULL باستخدام COALESCE
        COALESCE(dd.domain_id, -1) AS domain_id,
        COALESCE(di.instructor_id, -1) AS instructor_id,
        COALESCE(dl.language_id, -1) AS language_id,
        COALESCE(dlev.level_id, -1) AS level_id,
        COALESCE(dp.platform_id, -1) AS platform_id,
        COALESCE(dt.offering_type_id, -1) AS offering_type_id,
        COALESCE(ddt.date_id, -1) AS date_id,
        
        -- الـ Metrics
        f.course_id,
        f.rating,
        f.enrolled_students,
        f.review_count,
        f.estimated_total_cost,
        f.popularity_score,
        f.engagement_rate_pct

    FROM base_data f
    LEFT JOIN {{ ref('dim_offering') }} do ON f.course_id = do.offering_id
    LEFT JOIN {{ ref('dim_domain') }} dd ON f.domain_name = dd.domain_name
    LEFT JOIN {{ ref('dim_instructor') }} di ON f.instructor = di.instructor_name
    LEFT JOIN {{ ref('dim_language') }} dl ON f.language = dl.language_name
    LEFT JOIN {{ ref('dim_level') }} dlev ON f.level = dlev.level_name
    LEFT JOIN {{ ref('dim_platform') }} dp ON f.platform = dp.platform_name
    LEFT JOIN {{ ref('dim_offering_type') }} dt ON f.offering_type = dt.offering_type
    LEFT JOIN {{ ref('dim_date') }} ddt ON CAST(CONVERT(VARCHAR(8), f.last_updated, 112) AS INTEGER) = ddt.date_id
)

SELECT * FROM fact_data